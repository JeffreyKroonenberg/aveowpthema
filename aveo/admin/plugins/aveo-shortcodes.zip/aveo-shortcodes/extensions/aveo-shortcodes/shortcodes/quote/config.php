<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Quote', 'aveo-shortcodes' ),
		'description' => esc_html__( 'Add a Quote', 'aveo-shortcodes' ),
		'tab'         => esc_html__( 'AVEO Elements', 'aveo-shortcodes' ),
		'popup_size'  => 'medium'
	)
);