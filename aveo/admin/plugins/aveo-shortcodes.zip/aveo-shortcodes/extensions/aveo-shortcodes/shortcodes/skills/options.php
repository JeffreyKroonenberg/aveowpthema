<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'title'         => array(
		'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
		'desc'  => esc_html__( 'Option Skills Title', 'aveo-shortcodes' ),
		'type'  => 'text',
	),
	'skills' => array(
		'label'         => esc_html__( 'Skill', 'aveo-shortcodes' ),
		'popup-title'   => esc_html__( 'Add/Edit Skill', 'aveo-shortcodes' ),
		'desc'          => esc_html__( 'Here you can add, remove and edit your skill.', 'aveo-shortcodes' ),
		'type'          => 'addable-popup',
		'template'      => '{{=title}}',
		'popup-options' => array(
			'id'    => array(
				'type' => 'unique'
			),
			'title'       => array(
				'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Enter the title', 'aveo-shortcodes' ),
				'type'  => 'text',
			),
			'value'       => array(
				'label' => esc_html__( 'Value', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Enter the value (%)', 'aveo-shortcodes' ),
				'type'  => 'short-text',
			),
		)
	)
);