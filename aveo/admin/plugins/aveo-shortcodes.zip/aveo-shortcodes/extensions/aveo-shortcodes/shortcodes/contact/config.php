<?php if (!defined('FW')) die('Forbidden');
if ( function_exists( 'aveo_contact_action' ) ) {
    $cfg = array(
    	'page_builder' => array(
    		'title'       => esc_html__( 'Contact Form', 'aveo-shortcodes' ),
    		'description' => esc_html__( 'Contact Form', 'aveo-shortcodes' ),
    		'tab'         => esc_html__( 'AVEO Elements', 'aveo-shortcodes' ),
    	)
    );
}
