<?php if (!defined('FW')) die('Forbidden');

/**
 * @var $atts The shortcode attributes
 */

$title = $atts['title'];
$color_title_part = $atts['color_title_part'];
?>

<div class="block-title">
    <h3><?php echo esc_html($title); ?><?php $color_title_part != '' ?><span><?php echo esc_html($color_title_part); ?></span></h3>
</div>
