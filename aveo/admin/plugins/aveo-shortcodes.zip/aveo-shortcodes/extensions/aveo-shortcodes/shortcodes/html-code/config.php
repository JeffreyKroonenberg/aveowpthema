<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'HTML Code', 'aveo-shortcodes' ),
		'description' => esc_html__( 'Paste Code', 'aveo-shortcodes' ),
		'tab'         => esc_html__( 'AVEO Elements', 'aveo-shortcodes' ),
	)
);