<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'id' => array( 'type' => 'unique' ),
	'layout' => array(
		'label'   => esc_html__('Layout', 'aveo-shortcodes'),
		'desc'    => esc_html__('Choose the layout type', 'aveo-shortcodes'),
		'type'    => 'select',
		'value'   => 'three-columns',
		'choices' => array(
			'two-columns'   => esc_html__('2 Columns', 'aveo-shortcodes'),
			'three-columns' => esc_html__('3 Columns', 'aveo-shortcodes'),
			'four-columns' => esc_html__('4 Columns', 'aveo-shortcodes'),
		)
	),
	'categories' => array(
	    'type'  => 'multi-select',
	    'value' => '',
	    'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
	    'label' => __('Categories', 'aveo-shortcodes'),
	    'desc'  => __('Select the categories from which the projects will be displayed. If this field is empty, then projects will be displayed from all categories.', 'aveo-shortcodes'),
	    'population' => 'taxonomy',
	    'source' => 'fw-portfolio-category',
	)
);