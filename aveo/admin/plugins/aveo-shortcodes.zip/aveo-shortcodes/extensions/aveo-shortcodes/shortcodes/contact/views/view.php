<?php if (!defined('FW')) die('Forbidden');
/**
 * @var $atts The shortcode attributes
 */
$recaptcha = ( function_exists('fw_get_db_settings_option') ) ? fw_get_db_settings_option('recaptcha/recaptcha_switcher') : 'on';
$recaptcha_key = ( function_exists('fw_get_db_settings_option') ) ? fw_get_db_settings_option('recaptcha/on/recaptcha_key') : '6LdqmCAUAAAAAMMNEZvn6g4W5e0or2sZmAVpxVqI';
$id = uniqid( 'contact_form_' );
?>

<form id="<?php echo esc_attr($id); ?>" class="contact-form" action="#" method="post">

	<div class="messages"></div>

	<div class="controls">
		<div class="form-group form-group-with-icon">
			<i class="form-control-icon fa fa-user"></i>
			<label><?php esc_html_e('Full Name','aveo-shortcodes'); ?></label>
			<input id="form_name" type="text" name="name" class="form-control" required="required" data-error="<?php esc_html_e('Name is required.','aveo-shortcodes'); ?>">
			<div class="form-control-border"></div>
			<div class="help-block with-errors"></div>
		</div>

		<div class="form-group form-group-with-icon">
			<i class="form-control-icon fa fa-envelope"></i>
			<label><?php esc_html_e('Email Address','aveo-shortcodes'); ?></label>
			<input id="form_email" type="email" name="email" class="form-control" required="required" data-error="<?php esc_html_e('Valid email is required.','aveo-shortcodes'); ?>">
			<div class="form-control-border"></div>
			<div class="help-block with-errors"></div>
		</div>

		<div class="form-group form-group-with-icon">
			<i class="form-control-icon fa fa-comment"></i>
			<label><?php esc_html_e('Message for Me','aveo-shortcodes'); ?></label>
			<textarea id="form_message" name="message" class="form-control" rows="4" required="required" data-error="<?php esc_html_e('Please, leave me a message.','aveo-shortcodes'); ?>"></textarea>
			<div class="form-control-border"></div>
			<div class="help-block with-errors"></div>
		</div>

		<?php if( $recaptcha == 'on' ) { 
			?>
				<div class="g-recaptcha" data-sitekey="<?php echo esc_attr($recaptcha_key); ?>"></div>
			<?php
		} ?>

		<input type="submit" class="button btn-send" value="<?php esc_html_e('Send message','aveo-shortcodes'); ?>">
	</div>
</form>

