<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$id = uniqid( 'timeline-' );
?>

<?php if (!empty($atts['title'])): ?>
	<div class="block-title fw-timeline-title">
		<h3><?php echo esc_html($atts['title']); ?></h3>
	</div>
<?php endif; ?>

<div class="timeline" id="<?php echo esc_attr($id); ?>">
	<?php foreach ($atts['timeline'] as $timeline):

	$title = $timeline['title'];
	$period = $timeline['period'];
	$company = $timeline['subtitle'];
	$text = $timeline['text'];
	$logo = $timeline['logo'];
	?>
	<div class="timeline-item">
		<h4 class="item-title"><?php echo esc_html($title); ?></h4>
		<span class="item-period"><?php echo esc_html($period); ?></span>
		<span class="item-small"><?php echo esc_html($company); ?></span>
		<?php if( !empty( $logo ) ) : ?>
		<span class="item-logo"><img src="<?php echo esc_url($logo['url']); ?>" alt="<?php esc_attr_e('image', 'aveo-shortcodes'); ?>" /></span>
		<?php endif; ?>
		<p><?php echo wp_kses_post($text); ?></p>
	</div>
	<?php endforeach; ?>
</div>
