<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'id' => array( 'type' => 'unique' ),
	'clients_slider' => array(
		'label'         => esc_html__( 'Clients', 'aveo-shortcodes' ),
		'popup-title'   => esc_html__( 'Add/Edit Client Item', 'aveo-shortcodes' ),
		'desc'          => esc_html__( 'Here you can add, remove and edit Clients.', 'aveo-shortcodes' ),
		'type'          => 'addable-popup',
		'template'      => '{{=client_title}}',
		'popup-options' => array(
			'client_logo' => array(
				'label' => esc_html__( 'Logo', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Either upload a new, or choose an existing image from your media library', 'aveo-shortcodes' ),
				'type'  => 'upload',
			),
			'client_title'      => array(
				'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Link to the Clients website', 'aveo-shortcodes' ),
				'type'  => 'text'
			),
			'site_url'      => array(
				'label' => esc_html__( 'Website Link', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Link to the Clients website', 'aveo-shortcodes' ),
				'type'  => 'text'
			)
		)
	),
	'items'         => array(
		'label' => esc_html__( 'Items on the front: Desktop', 'aveo-shortcodes' ),
		'desc'  => esc_html__( 'Example: 2', 'aveo-shortcodes' ),
		'type'  => 'text',
		'value' => '3'
	),
	'items_tablet'         => array(
		'label' => esc_html__( 'Items on the front: Tablet', 'aveo-shortcodes' ),
		'desc'  => esc_html__( 'Example: 2', 'aveo-shortcodes' ),
		'type'  => 'text',
		'value' => '2'
	),
	'items_mobile'         => array(
		'label' => esc_html__( 'Items on the front: Mobile', 'aveo-shortcodes' ),
		'desc'  => esc_html__( 'Example: 2', 'aveo-shortcodes' ),
		'type'  => 'text',
		'value' => '1'
	)
);