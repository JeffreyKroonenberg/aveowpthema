<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'title'         => array(
		'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
		'desc'  => esc_html__( 'Option Contact Form 2 Title', 'aveo-shortcodes' ),
		'type'  => 'text',
	),
	'contact_form_pro' => array(
		'label'         => esc_html__( 'Contact Form Elements', 'aveo-shortcodes' ),
		'popup-title'   => esc_html__( 'Add/Edit Contact Form Elements', 'aveo-shortcodes' ),
		'desc'          => esc_html__( 'Here you can add, remove and edit your Contact Form 2 elements.', 'aveo-shortcodes' ),
		'type'          => 'addable-popup',
		'template'      => '{{=title}}',
		'popup-options' => array(
			'element_type'    => array(
			    'type'  => 'radio',
			    'value' => 'text',
			    'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
			    'label' => __('Element Type', 'aveo-shortcodes'),
			    'desc'  => __('The type of the form element.', 'aveo-shortcodes'),
			    'choices' => array(
			        'text' => __('Text Input', 'aveo-shortcodes'),
			        'textarea' => __('Textarea', 'aveo-shortcodes'),
			        'email' => __('E-Mail', 'aveo-shortcodes'),
			        'phone' => __('Phone', 'aveo-shortcodes'),
			        'checkbox' => __('Checkbox', 'aveo-shortcodes'),
			    ),
			    'inline' => false,
			),
			'title'       => array(
				'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Enter the title', 'aveo-shortcodes' ),
				'type'  => 'text',
			),
			'icon'    => array(
				'type'  => 'icon-v2',
				'label' => esc_html__('Choose an Icon', 'aveo-shortcodes'),
			),
			'error_message'       => array(
				'label' => esc_html__( 'Error Message', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Enter the error message', 'aveo-shortcodes' ),
				'type'  => 'text',
			),
			'required'       => array(
			    'type'  => 'switch',
			    'value' => 'on',
			    'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
			    'label' => __('Mandatory', 'aveo-shortcodes'),
			    'left-choice' => array(
			        'value' => 'off',
			        'label' => __('No', 'aveo-shortcodes'),
			    ),
			    'right-choice' => array(
			        'value' => 'on',
			        'label' => __('Yes', 'aveo-shortcodes'),
			    ),
			)
		)
	),
	'submit_btn_text'         => array(
		'label' => esc_html__( 'Submit Button Text', 'aveo-shortcodes' ),
		'type'  => 'text',
		'value' => esc_html__( 'Submit', 'aveo-shortcodes' ),
	),
);