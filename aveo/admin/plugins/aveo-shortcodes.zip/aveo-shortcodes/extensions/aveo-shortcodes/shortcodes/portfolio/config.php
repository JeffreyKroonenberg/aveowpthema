<?php if (!defined('FW')) die('Forbidden');

if ( function_exists( 'aveo_filter_portfolio_extension' ) ) {
    $cfg = array(
        'page_builder' => array(
            'title'       => esc_html__( 'Portfolio', 'aveo-shortcodes' ),
            'description' => esc_html__( 'Portfolio grid', 'aveo-shortcodes' ),
            'tab'         => esc_html__( 'AVEO Elements', 'aveo-shortcodes' ),
        )
    );
}