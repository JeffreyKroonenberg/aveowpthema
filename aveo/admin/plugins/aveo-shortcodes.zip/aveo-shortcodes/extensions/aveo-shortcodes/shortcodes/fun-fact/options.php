<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'icon'    => array(
		'type'  => 'icon-v2',
		'label' => esc_html__('Choose an Icon', 'aveo-shortcodes'),
	),
	'title'   => array(
		'type'  => 'text',
		'label' => esc_html__( 'Title of the Fun Fact', 'aveo-shortcodes' ),
	),
	'content' => array(
		'type'  => 'text',
		'label' => esc_html__( 'Content', 'aveo-shortcodes' ),
		'desc'  => esc_html__( 'Enter the desired content', 'aveo-shortcodes' ),
	),
	'style'   => array(
		'type'    => 'select',
		'label'   => esc_html__('Box Style', 'aveo-shortcodes'),
		'choices' => array(
			'gray-default' => esc_html__('Default Background', 'aveo-shortcodes'),
			'gray-bg' => esc_html__('Gray Background', 'aveo-shortcodes')
		)
	),
);