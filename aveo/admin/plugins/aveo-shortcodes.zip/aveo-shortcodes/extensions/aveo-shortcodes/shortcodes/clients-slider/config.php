<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Clients Slider', 'aveo-shortcodes' ),
	'description' => esc_html__( 'Add some Clients logos', 'aveo-shortcodes' ),
	'tab'         => esc_html__( 'AVEO Elements', 'aveo-shortcodes' ),
);