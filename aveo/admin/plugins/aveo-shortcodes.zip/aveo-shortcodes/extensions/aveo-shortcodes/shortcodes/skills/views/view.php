<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$id = uniqid( 'skills-' );
?>

<?php if (!empty($atts['title'])): ?>
	<div class="block-title fw-skills-title">
		<h3><?php echo esc_html($atts['title']); ?></h3>
	</div>
<?php endif; ?>

<div class="skills-info" id="<?php echo esc_attr($id); ?>">
	<?php foreach ($atts['skills'] as $skill): ?>
	<h4><?php echo esc_html($skill['title']); ?></h4>                               
	<div id="skill-<?php echo esc_attr($skill['id']); ?>" data-value="<?php echo esc_attr($skill['value']); ?>" class="skill-container">
		<div class="skill-percentage"></div>
	</div>
	<?php endforeach; ?>
</div>
