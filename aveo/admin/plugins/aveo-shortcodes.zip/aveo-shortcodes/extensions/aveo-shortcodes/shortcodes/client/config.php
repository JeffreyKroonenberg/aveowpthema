<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Client', 'aveo-shortcodes'),
	'description'   => esc_html__('Add an Client', 'aveo-shortcodes'),
	'tab'           => esc_html__('AVEO Elements', 'aveo-shortcodes'),
);