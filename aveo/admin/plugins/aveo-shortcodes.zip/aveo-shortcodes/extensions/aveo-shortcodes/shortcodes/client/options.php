<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'image'            => array(
		'type'  => 'upload',
		'label' => esc_html__( 'Choose Logo Image', 'aveo-shortcodes' ),
		'desc'  => esc_html__( 'Either upload a new, or choose an existing logo image from your media library', 'aveo-shortcodes' )
	),
	'size'             => array(
		'type'    => 'group',
		'options' => array(
			'width'  => array(
				'type'  => 'text',
				'label' => esc_html__( 'Width', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Set image width', 'aveo-shortcodes' ),
				'value' => 80
			),
			'height' => array(
				'type'  => 'text',
				'label' => esc_html__( 'Height', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Set image height', 'aveo-shortcodes' ),
				'value' => 80
			)
		)
	),
	'image-link-group' => array(
		'type'    => 'group',
		'options' => array(
			'link'   => array(
				'type'  => 'text',
				'label' => esc_html__( 'Logo Image Link', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Where should your logo image link to?', 'aveo-shortcodes' )
			),
			'target' => array(
				'type'         => 'switch',
				'label'        => esc_html__( 'Open Link in New Window', 'aveo-shortcodes' ),
				'desc'         => esc_html__( 'Select here if you want to open the linked page in a new window', 'aveo-shortcodes' ),
				'right-choice' => array(
					'value' => '_blank',
					'label' => esc_html__( 'Yes', 'aveo-shortcodes' ),
				),
				'left-choice'  => array(
					'value' => '_self',
					'label' => esc_html__( 'No', 'aveo-shortcodes' ),
				),
			),
		)
	)
);

