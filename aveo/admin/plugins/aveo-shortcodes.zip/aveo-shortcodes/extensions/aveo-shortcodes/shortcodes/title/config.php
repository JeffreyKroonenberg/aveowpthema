<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Page Title', 'aveo-shortcodes' ),
		'description' => esc_html__( 'Section title', 'aveo-shortcodes' ),
		'tab'         => esc_html__( 'AVEO Elements', 'aveo-shortcodes' ),
	)
);