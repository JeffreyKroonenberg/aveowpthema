<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'title'         => array(
		'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
		'desc'  => esc_html__( 'Option Social Title', 'aveo-shortcodes' ),
		'type'  => 'text',
	),
	'social' => array(
		'label'         => esc_html__( 'Social Icons', 'aveo-shortcodes' ),
		'popup-title'   => esc_html__( 'Add/Edit Social Icons', 'aveo-shortcodes' ),
		'desc'          => esc_html__( 'Here you can add, remove and edit your Social Icons.', 'aveo-shortcodes' ),
		'type'          => 'addable-popup',
		'template'      => '{{=title}}',
		'popup-options' => array(
			'icon'    => array(
				'type'  => 'icon-v2',
				'label' => esc_html__('Choose an Icon', 'aveo-shortcodes'),
			),
			'title'       => array(
				'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Enter the title', 'aveo-shortcodes' ),
				'type'  => 'text',
			),
			'link'   => array(
				'type'  => 'text',
				'label' => esc_html__( 'Link', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Where should your link to?', 'aveo-shortcodes' )
			),
			'target' => array(
				'type'         => 'switch',
				'label'        => esc_html__( 'Open Link in New Window', 'aveo-shortcodes' ),
				'desc'         => esc_html__( 'Select here if you want to open the linked page in a new window', 'aveo-shortcodes' ),
				'right-choice' => array(
					'value' => '_blank',
					'label' => esc_html__( 'Yes', 'aveo-shortcodes' ),
				),
				'left-choice'  => array(
					'value' => '_self',
					'label' => esc_html__( 'No', 'aveo-shortcodes' ),
				),
			),
		)
	)
);