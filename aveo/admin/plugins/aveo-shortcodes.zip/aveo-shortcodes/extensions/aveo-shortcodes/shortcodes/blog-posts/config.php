<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
    'page_builder' => array(
        'title'       => esc_html__( 'Blog Posts', 'aveo-shortcodes' ),
        'description' => esc_html__( 'Blog posts grid', 'aveo-shortcodes' ),
        'tab'         => esc_html__( 'AVEO Elements', 'aveo-shortcodes' ),
    )
);
