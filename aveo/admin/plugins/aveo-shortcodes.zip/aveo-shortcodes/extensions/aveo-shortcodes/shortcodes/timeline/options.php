<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'title'         => array(
		'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
		'desc'  => esc_html__( 'Option Timeline Title', 'aveo-shortcodes' ),
		'type'  => 'text',
	),
	'timeline' => array(
		'label'         => esc_html__( 'Timeline', 'aveo-shortcodes' ),
		'popup-title'   => esc_html__( 'Add/Edit Timeline', 'aveo-shortcodes' ),
		'desc'          => esc_html__( 'Here you can add, remove and edit timeline.', 'aveo-shortcodes' ),
		'type'          => 'addable-popup',
		'template'      => '{{=period}}',
		'popup-options' => array(
			'period'       => array(
				'label' => esc_html__( 'Period', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Enter the period', 'aveo-shortcodes' ),
				'type'  => 'text',
			),
			'title'       => array(
				'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Enter the title', 'aveo-shortcodes' ),
				'type'  => 'text',
			),
			'subtitle'       => array(
				'label' => esc_html__( 'Subtitle', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Enter the subtitle', 'aveo-shortcodes' ),
				'type'  => 'text',
			),
			'text'       => array(
				'label' => esc_html__( 'Text', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Enter the some text', 'aveo-shortcodes' ),
				'type'  => 'textarea',
			),
			'logo'	=> array(
				'label' => esc_html__( 'Logo', 'aveo' ),
				'desc'  => esc_html__( 'Upload a logo image.', 'aveo' ),
				'type'  => 'upload'
			),
		)
	)
);