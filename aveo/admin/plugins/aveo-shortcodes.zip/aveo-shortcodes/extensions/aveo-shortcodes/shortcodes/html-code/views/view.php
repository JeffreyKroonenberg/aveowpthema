<?php if (!defined('FW')) die('Forbidden');

/**
 * @var $atts The shortcode attributes
 */

$code = $atts['code'];
?>

<p><?php echo wp_kses_post($code); ?></p>