<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Skills', 'aveo-shortcodes' ),
	'description' => esc_html__( 'Skills block', 'aveo-shortcodes' ),
	'tab'         => esc_html__( 'AVEO Elements', 'aveo-shortcodes' ),
);