<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Info List 2', 'aveo-shortcodes' ),
	'description' => esc_html__( 'Add some Information', 'aveo-shortcodes' ),
	'tab'         => esc_html__( 'AVEO Elements', 'aveo-shortcodes' ),
);