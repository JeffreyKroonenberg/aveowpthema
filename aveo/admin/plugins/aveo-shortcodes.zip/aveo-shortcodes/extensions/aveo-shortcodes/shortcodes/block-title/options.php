<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'title' => array(
		'label'   => esc_html__('Title', 'aveo-shortcodes'),
		'desc'    => esc_html__('Write some text', 'aveo-shortcodes'),
		'type'    => 'text',
	),
    'color_title_part' => array(
        'label'   => esc_html__('Color Part of Title', 'aveo-shortcodes'),
        'desc'    => esc_html__('Write some text', 'aveo-shortcodes'),
        'type'    => 'text',
    )
);