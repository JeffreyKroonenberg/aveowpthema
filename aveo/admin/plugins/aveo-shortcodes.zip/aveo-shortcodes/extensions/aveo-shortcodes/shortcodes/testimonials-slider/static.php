<?php if (!defined('FW')) die('Forbidden');


wp_enqueue_script(
    'aveo-shortcode-testimonials-slider',
    plugin_dir_url( __FILE__ ) . 'static/js/scripts.js'
);
