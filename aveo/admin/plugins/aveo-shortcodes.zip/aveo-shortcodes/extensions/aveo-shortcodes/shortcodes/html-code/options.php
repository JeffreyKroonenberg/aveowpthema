<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'code' => array(
		'label'   => esc_html__('Code', 'aveo-shortcodes'),
		'desc'    => esc_html__('Write some text', 'aveo-shortcodes'),
		'type'    => 'textarea',
	)
);