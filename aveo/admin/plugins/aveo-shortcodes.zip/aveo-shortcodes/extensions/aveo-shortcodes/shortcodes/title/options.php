<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'title' => array(
		'label'   => esc_html__('Title', 'aveo-shortcodes'),
		'desc'    => esc_html__('Write some text', 'aveo-shortcodes'),
		'type'    => 'text',
	),
	'subtitle' => array(
		'label'   => esc_html__('Subtitle', 'aveo-shortcodes'),
		'desc'    => esc_html__('Write some text', 'aveo-shortcodes'),
		'type'    => 'text',
	)
);