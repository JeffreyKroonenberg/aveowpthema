<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'title'         => array(
		'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
		'desc'  => esc_html__( 'Option Info List Title', 'aveo-shortcodes' ),
		'type'  => 'text',
	),
	'infolist_with_icons' => array(
		'label'         => esc_html__( 'Info List', 'aveo-shortcodes' ),
		'popup-title'   => esc_html__( 'Add/Edit Info List Item', 'aveo-shortcodes' ),
		'desc'          => esc_html__( 'Here you can add, remove and edit your Info List.', 'aveo-shortcodes' ),
		'type'          => 'addable-popup',
		'template'      => '{{=title}}',
		'popup-options' => array(
			'icon'    => array(
				'type'  => 'icon-v2',
				'label' => esc_html__('Choose an Icon', 'aveo-shortcodes'),
			),
			'title'       => array(
				'label' => esc_html__( 'Title', 'aveo-shortcodes' ),
				'desc'  => esc_html__( 'Enter the title', 'aveo-shortcodes' ),
				'type'  => 'text',
			),
		)
	)
);