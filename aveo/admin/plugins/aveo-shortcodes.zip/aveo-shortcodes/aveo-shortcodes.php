<?php
/*
Plugin Name: Aveo Shortcodes
Plugin URI: http://lmpixels.com
Description: Aveo Theme Shortcodes
Author: LMPixels
Version: 1.1.0
*/

add_action( 'plugins_loaded', 'aveo_shortcodes_textdomain' );

function aveo_shortcodes_textdomain() {
    load_plugin_textdomain( 'aveo-shortcodes', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
}

function aveo_filter_plugin_shortcodes($locations) {
	$locations[
		dirname(__FILE__) . '/extensions'
	] = plugin_dir_url( __FILE__ ) . 'extensions';

	return $locations;
}

add_filter('fw_extensions_locations', 'aveo_filter_plugin_shortcodes');
