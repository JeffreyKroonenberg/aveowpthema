<?php
/*
Plugin Name: Aveo Portfolio
Plugin URI: http://lmpixels.com
Description: Aveo Theme Portfolio
Author: LMPixels
Version: 1.0.8
*/

add_action( 'plugins_loaded', 'aveo_portfolio_textdomain' );

function aveo_portfolio_textdomain() {
    load_plugin_textdomain( 'aveo-portfolio', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
}

if( ! function_exists( 'aveo_filter_portfolio_extension' ) ){
    function aveo_filter_portfolio_extension($locations) {
    	$locations[
    		dirname(__FILE__) . '/extensions'
    	] = plugin_dir_url( __FILE__ ) . 'extensions';

    	return $locations;
    }
}
add_filter('fw_extensions_locations', 'aveo_filter_portfolio_extension');